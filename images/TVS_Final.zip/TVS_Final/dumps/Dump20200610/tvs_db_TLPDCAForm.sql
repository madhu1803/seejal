-- MySQL dump 10.13  Distrib 8.0.20, for macos10.15 (x86_64)
--
-- Host: 127.0.0.1    Database: tvs_db
-- ------------------------------------------------------
-- Server version	8.0.19

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `TLPDCAForm`
--

DROP TABLE IF EXISTS `TLPDCAForm`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `TLPDCAForm` (
  `id` int NOT NULL AUTO_INCREMENT,
  `date` date DEFAULT (curdate()),
  `tl1_cb1` text,
  `tl1_cb2` text,
  `tl1_cb3` text,
  `tl1_cb4` text,
  `tl1_cb5` text,
  `tl1_cb6` text,
  `tl1_cb7` text,
  `tl1_cb8` text,
  `tl1_cb9` text,
  `tl1_cb10` text,
  `tl1_cb11` text,
  `tl1_cb12` text,
  `tl1_cb13` text,
  `tl1_cb14` text,
  `tl1_cb15` text,
  `tl1_cb16` text,
  `tl1_ta1` text,
  `tl1_ta2` text,
  `tl1_ta3` text,
  `tl1_ta4` text,
  `tl1_ta5` text,
  `tl1_ta6` text,
  `tl1_ta7` text,
  `tl1_ta8` text,
  `tl1_ta9` text,
  `tl1_ta10` text,
  `tl1_ta11` text,
  `tl1_ta12` text,
  `tl1_ta13` text,
  `tl1_in1` text,
  `tl1_in2` text,
  `tl1_in3` text,
  `tl1_in4` text,
  `tl1_in5` text,
  `tl1_in6` text,
  `tl1_in7` text,
  `tl1_in8` text,
  `tl1_in9` text,
  `tl1_in10` text,
  `tl1_in11` text,
  `tl1_in12` text,
  `tl1_in13` text,
  `tl1_in14` text,
  `tl1_in15` text,
  `tl1_in16` text,
  `tl1_in17` text,
  `tl1_in18` text,
  `tl1_in19` text,
  `tl1_in20` text,
  `tl1_in21` text,
  `tl1_in22` text,
  `tl1_in23` text,
  `tl1_in24` text,
  `tl1_in25` text,
  `tl1_in26` text,
  `tl1_in27` text,
  `tl1_in28` text,
  `tl1_in29` text,
  `tl1_in30` text,
  `tl1_in31` text,
  `tl1_in32` text,
  `tl1_in33` text,
  `tl1_in34` text,
  `tl1_in35` text,
  `tl1_in36` text,
  `tl1_in37` text,
  `tl1_in38` text,
  `tl1_in39` text,
  `tl1_in40` text,
  `tl1_in41` text,
  `tl1_in42` text,
  `tl1_in43` text,
  `tl1_in44` text,
  `tl1_in45` text,
  `tl1_in46` text,
  `tl1_in47` text,
  `tl1_in48` text,
  `tl1_in49` text,
  `tl1_in50` text,
  `tl1_in51` text,
  `tl1_in52` text,
  `tl1_in53` text,
  `tl1_in54` text,
  `tl1_in55` text,
  `tl1_in56` text,
  `tl1_in57` text,
  `tl1_in58` text,
  `tl1_in59` text,
  `tl1_in60` text,
  `tl1_in61` text,
  `tl1_in62` text,
  `tl1_in63` text,
  `tl1_in64` text,
  `tl1_in65` text,
  `tl1_in66` text,
  `tl1_in67` text,
  `tl1_in68` text,
  `tl1_in69` text,
  `tl1_in70` text,
  `tl1_in71` text,
  `tl1_in72` text,
  `tl1_in73` text,
  `tl1_in74` text,
  `tl1_in75` text,
  `tl1_in76` text,
  `tl1_in77` text,
  `tl1_in78` text,
  `tl1_in79` text,
  `tl1_in80` text,
  `tl1_in81` text,
  `tl1_in82` text,
  `tl1_in83` text,
  `tl1_in84` text,
  `tl1_in85` text,
  `tl1_in86` text,
  `tl1_in87` text,
  `tl1_in88` text,
  `tl1_in89` text,
  `tl1_in90` text,
  `tl1_in91` text,
  `tl1_in92` text,
  `tl1_in93` text,
  `tl1_in94` text,
  `tl1_in95` text,
  `tl1_in96` text,
  `tl1_in97` text,
  `tl1_in98` text,
  `tl1_in99` text,
  `tl1_in100` text,
  `tl1_in101` text,
  `tl1_in102` text,
  `tl1_in103` text,
  `tl1_in104` text,
  `tl1_in105` text,
  `tl1_in106` text,
  `tl1_in107` text,
  `tl1_in108` text,
  `tl1_in109` text,
  `tl1_in110` text,
  `tl1_in111` text,
  `tl1_in112` text,
  `tl1_in113` text,
  `tl1_in114` text,
  `tl1_in115` text,
  `tl1_in116` text,
  `tl1_in117` text,
  `tl1_in118` text,
  `tl1_in119` text,
  `tl1_in120` text,
  `tl1_in121` text,
  `tl1_in122` text,
  `tl1_in123` text,
  `tl1_in124` text,
  `tl1_in125` text,
  `tl1_in126` text,
  `tl1_in127` text,
  `tl1_in128` text,
  `tl1_in129` text,
  `tl1_in130` text,
  `tl1_in131` text,
  `tl1_in132` text,
  `tl1_in133` text,
  `tl1_in134` text,
  `tl1_in135` text,
  `tl1_in136` text,
  `tl1_in137` text,
  `tl1_in138` text,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `TLPDCAForm`
--

LOCK TABLES `TLPDCAForm` WRITE;
/*!40000 ALTER TABLE `TLPDCAForm` DISABLE KEYS */;
INSERT INTO `TLPDCAForm` VALUES (1,'2020-06-10',NULL,NULL,'y','y',NULL,'y','y','y',NULL,'y','y',NULL,'y',NULL,'y','y','Debit','Modi ','Vel n','Fugit','Aut n','Maxim','Place','16','Sit v','Provi','10','','Offic','Eum l','Magni',NULL,'Omnis',NULL,'Conse','Ducim','Qui m','Ut om','Odit ','Volup','Molli','Est s','Archi','Est ','Ea qu','Quo n','Magna','At ut','Atque','Aut f','Qui e','Ipsum','Dolor','Exerc','Nostr','Anim ','Et do','Sint ','Magni','Aut o','Incid','Aute ','Volup','Volup','Vero ','Expli','Velit','Animi','Nihil','Nam a','Non d','Sint','Nostr','Ut co','Natus','Tempo','Quibu','Quas ','Aliqu','Porro','Volup','Accus','Quo t','Autem','Molli','Maior','Dolor','In la','Quia ','Molli','Dolor','Aut r','Sed n','Aut a','Incid','Labor','Eius ','Commo','Harum','Sed d','Saepe','Quia ','Fugit','Quas ','Et qu','Sunt ','Nam o','Ex qu','Est p','Dolor','Culpa','Vel v','Exerc','Et eu','Assum','Aliqu','Sed a','Volup','Volup','Dolor','In ra','Dicta','Cumqu','Earum','Aliqu','In mo','Velit','Dolor','Dolor','Dolor','Disti','Et se','Sed m','Sed v','Nam f','Ut al','Dolor','Ad pa','Excep','Cupid','Labor','Ab du','Tempo','Digni','Ex an','Elit','Totam','Dolor','Amet','Optio','Dicta','Minus','Dolor','Quos ','Dolor','Vel i','Liber','In qu','Velit','Quaer','Maior','Ut ve','Ullam','Est ','Ratio','Aut v','Sit ');
/*!40000 ALTER TABLE `TLPDCAForm` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2020-06-10 18:36:00
