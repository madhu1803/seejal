-- MySQL dump 10.13  Distrib 8.0.20, for macos10.15 (x86_64)
--
-- Host: 127.0.0.1    Database: tvs_db
-- ------------------------------------------------------
-- Server version	8.0.19

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `TLPDCA2Form`
--

DROP TABLE IF EXISTS `TLPDCA2Form`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `TLPDCA2Form` (
  `id` int NOT NULL AUTO_INCREMENT,
  `date` date DEFAULT (curdate()),
  `tl2_cb1` text,
  `tl2_cb2` text,
  `tl2_cb3` text,
  `tl2_cb4` text,
  `tl2_cb5` text,
  `tl2_cb6` text,
  `tl2_cb7` text,
  `tl2_cb8` text,
  `tl2_cb9` text,
  `tl2_cb10` text,
  `tl2_cb11` text,
  `tl2_cb12` text,
  `tl2_cb13` text,
  `tl2_cb14` text,
  `tl2_cb15` text,
  `tl2_cb16` text,
  `tl2_ta1` text,
  `tl2_ta2` text,
  `tl2_ta3` text,
  `tl2_ta4` text,
  `tl2_ta5` text,
  `tl2_ta6` text,
  `tl2_ta7` text,
  `tl2_ta8` text,
  `tl2_ta9` text,
  `tl2_ta10` text,
  `tl2_ta11` text,
  `tl2_ta12` text,
  `tl2_ta13` text,
  `tl2_in1` text,
  `tl2_in2` text,
  `tl2_in3` text,
  `tl2_in4` text,
  `tl2_in5` text,
  `tl2_in6` text,
  `tl2_in7` text,
  `tl2_in8` text,
  `tl2_in9` text,
  `tl2_in10` text,
  `tl2_in11` text,
  `tl2_in12` text,
  `tl2_in13` text,
  `tl2_in14` text,
  `tl2_in15` text,
  `tl2_in16` text,
  `tl2_in17` text,
  `tl2_in18` text,
  `tl2_in19` text,
  `tl2_in20` text,
  `tl2_in21` text,
  `tl2_in22` text,
  `tl2_in23` text,
  `tl2_in24` text,
  `tl2_in25` text,
  `tl2_in26` text,
  `tl2_in27` text,
  `tl2_in28` text,
  `tl2_in29` text,
  `tl2_in30` text,
  `tl2_in31` text,
  `tl2_in32` text,
  `tl2_in33` text,
  `tl2_in34` text,
  `tl2_in35` text,
  `tl2_in36` text,
  `tl2_in37` text,
  `tl2_in38` text,
  `tl2_in39` text,
  `tl2_in40` text,
  `tl2_in41` text,
  `tl2_in42` text,
  `tl2_in43` text,
  `tl2_in44` text,
  `tl2_in45` text,
  `tl2_in46` text,
  `tl2_in47` text,
  `tl2_in48` text,
  `tl2_in49` text,
  `tl2_in50` text,
  `tl2_in51` text,
  `tl2_in52` text,
  `tl2_in53` text,
  `tl2_in54` text,
  `tl2_in55` text,
  `tl2_in56` text,
  `tl2_in57` text,
  `tl2_in58` text,
  `tl2_in59` text,
  `tl2_in60` text,
  `tl2_in61` text,
  `tl2_in62` text,
  `tl2_in63` text,
  `tl2_in64` text,
  `tl2_in65` text,
  `tl2_in66` text,
  `tl2_in67` text,
  `tl2_in68` text,
  `tl2_in69` text,
  `tl2_in70` text,
  `tl2_in71` text,
  `tl2_in72` text,
  `tl2_in73` text,
  `tl2_in74` text,
  `tl2_in75` text,
  `tl2_in76` text,
  `tl2_in77` text,
  `tl2_in78` text,
  `tl2_in79` text,
  `tl2_in80` text,
  `tl2_in81` text,
  `tl2_in82` text,
  `tl2_in83` text,
  `tl2_in84` text,
  `tl2_in85` text,
  `tl2_in86` text,
  `tl2_in87` text,
  `tl2_in88` text,
  `tl2_in89` text,
  `tl2_in90` text,
  `tl2_in91` text,
  `tl2_in92` text,
  `tl2_in93` text,
  `tl2_in94` text,
  `tl2_in95` text,
  `tl2_in96` text,
  `tl2_in97` text,
  `tl2_in98` text,
  `tl2_in99` text,
  `tl2_in100` text,
  `tl2_in101` text,
  `tl2_in102` text,
  `tl2_in103` text,
  `tl2_in104` text,
  `tl2_in105` text,
  `tl2_in106` text,
  `tl2_in107` text,
  `tl2_in108` text,
  `tl2_in109` text,
  `tl2_in110` text,
  `tl2_in111` text,
  `tl2_in112` text,
  `tl2_in113` text,
  `tl2_in114` text,
  `tl2_in115` text,
  `tl2_in116` text,
  `tl2_in117` text,
  `tl2_in118` text,
  `tl2_in119` text,
  `tl2_in120` text,
  `tl2_in121` text,
  `tl2_in122` text,
  `tl2_in123` text,
  `tl2_in124` text,
  `tl2_in125` text,
  `tl2_in126` text,
  `tl2_in127` text,
  `tl2_in128` text,
  `tl2_in129` text,
  `tl2_in130` text,
  `tl2_in131` text,
  `tl2_in132` text,
  `tl2_in133` text,
  `tl2_in134` text,
  `tl2_in135` text,
  `tl2_in136` text,
  `tl2_in137` text,
  `tl2_in138` text,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `TLPDCA2Form`
--

LOCK TABLES `TLPDCA2Form` WRITE;
/*!40000 ALTER TABLE `TLPDCA2Form` DISABLE KEYS */;
INSERT INTO `TLPDCA2Form` VALUES (1,'2020-06-10',NULL,'y','y','y',NULL,NULL,NULL,NULL,NULL,'y','y',NULL,NULL,'y',NULL,NULL,'Commo','Archi','Conse','In vo','Enim ','Est o','Conse','16','Debit','Ex te','6','Odit ','Rerum','Moles','Anim ',NULL,'Et ve',NULL,'Dolor','Asper','Minim','Dolor','Aut t','Sunt','Harum','Ut qu','Asper','Non n','Ut ve','Saepe','In et','Assum','Nihil','Rerum','Ut au','Odio ','Exped','madhu','Minim','Quod ','Enim ','Sapie','Omnis','Volup','Beata','Cillu','Elige','Unde ','Sapie','Repre','Nobis','Fugit','Sequi','Nam q','Qui r','Ab au','Molli','Error','Aut r','Fugit','Venia','Moles','Quos ','Proid','Volup','Illum','Et ve','Anim ','Conse','Molli','Simil','Vel e','Quasi','Modi ','Facer','Place','Eum q','Asper','Aut v','Do si','Iure ','Error','Elit','Vitae','Est ','Rem m','Nihil','Volup','Est a','Et qu','Deser','Elit','Conse','Sed u','Quisq','Est c','Praes','Dolor','Quasi','Dolor','Id m','Eos a','Ipsum','Ut eo','Quia ','Ad qu','Lorem','Atque','Aliqu','Asper','Iste ','Eos ','Quide','Alias','Accus','Omnis','Nam d','Volup','Dolor','Id se','Venia','Liber','Vel n','Debit','Est m','Qui e','Expli','Ea vi','Quia ','Omnis','Ut mi','Nihil','Duis ','Susci','Et ha','Minim','Et ha','Qui r','Ut te','Lauda','Lauda','Eos a','Magna','Labor','Error','Culpa','Minim','Id do','Ut si','Eu co','Ea di');
/*!40000 ALTER TABLE `TLPDCA2Form` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2020-06-10 18:36:01
