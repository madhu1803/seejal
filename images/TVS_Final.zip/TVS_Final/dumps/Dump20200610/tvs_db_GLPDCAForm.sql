-- MySQL dump 10.13  Distrib 8.0.20, for macos10.15 (x86_64)
--
-- Host: 127.0.0.1    Database: tvs_db
-- ------------------------------------------------------
-- Server version	8.0.19

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `GLPDCAForm`
--

DROP TABLE IF EXISTS `GLPDCAForm`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `GLPDCAForm` (
  `id` int NOT NULL AUTO_INCREMENT,
  `date` date DEFAULT (curdate()),
  `gl_cb1` text,
  `gl_cb2` text,
  `gl_cb3` text,
  `gl_cb4` text,
  `gl_cb5` text,
  `gl_cb6` text,
  `gl_cb7` text,
  `gl_cb8` text,
  `gl_cb9` text,
  `gl_cb10` text,
  `gl_ta1` text,
  `gl_ta2` text,
  `gl_ta3` text,
  `gl_ta4` text,
  `gl_ta5` text,
  `gl_ta6` text,
  `gl_ta7` text,
  `gl_ta8` text,
  `gl_ta9` text,
  `gl_ta10` text,
  `gl_ta11` text,
  `gl_ta12` text,
  `gl_ta13` text,
  `gl_ta14` text,
  `gl_ta15` text,
  `gl_ta16` text,
  `gl_ta17` text,
  `gl_ta18` text,
  `gl_ta19` text,
  `gl_ta20` text,
  `gl_ta21` text,
  `gl_ta22` text,
  `gl_ta23` text,
  `gl_ta24` text,
  `gl_ta25` text,
  `gl_ta26` text,
  `gl_ta27` text,
  `gl_ta28` text,
  `gl_ta29` text,
  `gl_ta30` text,
  `gl_ta31` text,
  `gl_ta32` text,
  `gl_ta33` text,
  `gl_ta34` text,
  `gl_ta35` text,
  `gl_in1` text,
  `gl_in2` text,
  `gl_in3` text,
  `gl_in4` text,
  `gl_in5` text,
  `gl_in6` text,
  `gl_in7` text,
  `gl_in8` text,
  `gl_in9` text,
  `gl_in10` text,
  `gl_in11` text,
  `gl_in12` text,
  `gl_in13` text,
  `gl_in14` text,
  `gl_in15` text,
  `gl_in16` text,
  `gl_in17` text,
  `gl_in18` text,
  `gl_in19` text,
  `gl_in20` text,
  `gl_in21` text,
  `gl_in22` text,
  `gl_in23` text,
  `gl_in24` text,
  `gl_in25` text,
  `gl_in26` text,
  `gl_in27` text,
  `gl_in28` text,
  `gl_in29` text,
  `gl_in30` text,
  `gl_in31` text,
  `gl_in32` text,
  `gl_in33` text,
  `gl_in34` text,
  `gl_in35` text,
  `gl_in36` text,
  `gl_in37` text,
  `gl_in38` text,
  `gl_in39` text,
  `gl_in40` text,
  `gl_in41` text,
  `gl_in42` text,
  `gl_in43` text,
  `gl_in44` text,
  `gl_in45` text,
  `gl_in46` text,
  `gl_in47` text,
  `gl_in48` text,
  `gl_in49` text,
  `gl_in50` text,
  `gl_in51` text,
  `gl_in52` text,
  `gl_in53` text,
  `gl_in54` text,
  `gl_in55` text,
  `gl_in56` text,
  `gl_in57` text,
  `gl_in58` text,
  `gl_in59` text,
  `gl_in60` text,
  `gl_in61` text,
  `gl_in62` text,
  `gl_in63` text,
  `gl_in64` text,
  `gl_in65` text,
  `gl_in66` text,
  `gl_in67` text,
  `gl_in68` text,
  `gl_in69` text,
  `gl_in70` text,
  `gl_in71` text,
  `gl_in72` text,
  `gl_in73` text,
  `gl_in74` text,
  `gl_in75` text,
  `gl_in76` text,
  `gl_in77` text,
  `gl_in78` text,
  `gl_in79` text,
  `gl_in80` text,
  `gl_in81` text,
  `gl_in82` text,
  `gl_in83` text,
  `gl_in84` text,
  `gl_in85` text,
  `gl_in86` text,
  `gl_in87` text,
  `gl_in88` text,
  `gl_in89` text,
  `gl_in90` text,
  `gl_in91` text,
  `gl_in92` text,
  `gl_in93` text,
  `gl_in94` text,
  `gl_in95` text,
  `gl_in96` text,
  `gl_in97` text,
  `gl_in98` text,
  `gl_in99` text,
  `gl_in100` text,
  `gl_in101` text,
  `gl_in102` text,
  `gl_in103` text,
  `gl_in104` text,
  `gl_in105` text,
  `gl_in106` text,
  `gl_in107` text,
  `gl_in108` text,
  `gl_in109` text,
  `gl_in110` text,
  `gl_in111` text,
  `gl_in112` text,
  `gl_in113` text,
  `gl_in114` text,
  `gl_in115` text,
  `gl_in116` text,
  `gl_in117` text,
  `gl_in118` text,
  `gl_in119` text,
  `gl_in120` text,
  `gl_in121` text,
  `gl_in122` text,
  `gl_in123` text,
  `gl_in124` text,
  `gl_in125` text,
  `gl_in126` text,
  `gl_in127` text,
  `gl_in128` text,
  `gl_in129` text,
  `gl_in130` text,
  `gl_in131` text,
  `gl_in132` text,
  `gl_in133` text,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `GLPDCAForm`
--

LOCK TABLES `GLPDCAForm` WRITE;
/*!40000 ALTER TABLE `GLPDCAForm` DISABLE KEYS */;
INSERT INTO `GLPDCAForm` VALUES (1,'2020-06-10','y',NULL,NULL,'y','y',NULL,'y',NULL,NULL,'y','Moles','Maior','Volup','5','Deser','Cum i','Nesci','Labor','Dolor','Deser','Facil','Esse','Quia ','Beata','Neque','Commo','Fugia','Duis ','Amet','Illum','Aut v','Molli','Cupid','Cillu','Est o','Assum','Animi','Excep','Rerum','Eius ','Quia ','Volup','Conse','Commo','Amet','Deser','Expli','Corpo','Alias','Fugia','Corru','Delec','Id n','Irure','Rerum','In in','Excep','Esse ','Tempo','Optio','Aut n','Nesci','Delen','Tempo','Hic v','Volup','Est r','Ratio','Digni','Rem r','Animi','Digni','Iste ','ma','Facil','Minus','Error','Volup','Vitae','Id q','Aute ','Aut q','Deser','Ut se','Lorem','Qui a','Illum','Nostr','Amet','Labor','Excep','Ipsum','Quia ','Dolor','Tempo','Corpo','10','Aut d','Conse','Volup','Iste ','Nostr','Numqu','Excep','Nam b','Qui a','Excep','Digni','Qui c','Ipsum','Possi','Maxim','Recus','Tempo','Magni','Repel','Aut u','Aut N','Perfe','Eos n','Quod ','Neque','Exerc','Ullam','Optio','Sint ','Vel n','Sed s','Conse','Quis ','Quam ','Expli','Expli','Quia ','In re','Aut a','Fuga','Volup','Corpo','Rem u','Hic e','Nihil','Et nu','Labor','Conse','Beata','Fuga','Enim ','Beata','Molli','Conse','Venia','Incid','Ipsum','Volup','Est e','Rerum','Conse','Saepe','Assum','Solut','Est a','Sapie','Quos ','Exerc','Rerum','Digni','Volup','Lorem','Vero ','Eos a','Non e','Quia ','Asper','Dicta','Ea si','Quaer','Volup');
/*!40000 ALTER TABLE `GLPDCAForm` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2020-06-10 18:36:01
