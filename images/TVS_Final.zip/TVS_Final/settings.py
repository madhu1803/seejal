import os

from dotenv import load_dotenv

from forms import TLPDCA2Form, GLPDCAForm, TLPDCAForm

load_dotenv()

# database connection settings
DATABASE_USER = os.getenv("DATABASE_USER")
DATABASE_PASSWORD = os.getenv("DATABASE_PASSWORD")
DATABASE_HOST = os.getenv("DATABASE_HOST")
DATABASE_NAME = os.getenv("DATABASE_NAME")

# app config
SECRET_KEY = os.getenv("SECRET_KEY")
DEBUG = os.getenv("DEBUG") == "True"
ENV = os.getenv("ENV")

# forms defined to handle the tables
TABLES = [GLPDCAForm, TLPDCAForm, TLPDCA2Form]
