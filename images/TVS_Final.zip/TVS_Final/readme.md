# TVS Forms

## Getting Started Locally  

1. Create a virtual environment using `virtualenv`, activate the environment and install
the requirements from `requirements.txt`.  

2. Duplicate the `.env.example` to `.env` & set the necessary environment variables.  

3. Now the app know the database to connect to and the config for the database. Migrate the database
and load the initial tables and columns into the db. Use the following command => `python db.py`. If you already
have populated your db, you don't have to do this again, skip to `step 4`.  

4. Now that you have populated the database and have everything ready, run the application => `python app.py`.
Visit the app in `localhost:5000`.  